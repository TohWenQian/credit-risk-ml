import sys
import xgboost as xgb
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from lime.lime_tabular import LimeTabularExplainer
from IPython.display import display, HTML
import lime
from datetime import datetime
import os
from pathlib import Path
dir = Path.cwd()
jsonmodel = os.path.join(dir,"src","main","resources","XGBoost","xgboost_model.json")

model = xgb.XGBClassifier()

model.load_model(jsonmodel)
# Read input features from command-line arguments
features = np.array([float(x) for x in sys.argv[1:]]).reshape(1, -1)

# Define the order of the risk categories
risk_category_order = {
    'Lowest Risk': 0,
    'Low Risk': 1,
    'Medium Risk': 2,
    'High Risk': 3,
    'Very High Risk': 4,
    'Default': 5
}

# Make the prediction
predicted_class_encoded = model.predict(features)

# Inverse the numerical encoding to original labels for an interpretable report
inverse_risk_category_order = {v: k for k, v in risk_category_order.items()}
original_labels = [inverse_risk_category_order[pred] for pred in predicted_class_encoded]

# Convert the encoded prediction back to the original label using custom mapping
predicted_class = inverse_risk_category_order[predicted_class_encoded[0]]


# Define important features
important_features = [
    'Retained Earnings',
    'Total debt/total asset', 
    'Employees',
    'total asset/total liabilities',  
    'gross profit/rev', 
    'Cash',
    'EBTI/total asset', 
    'EBTI/REV',  
    'Net Cash Flow'
]
# Initialize LIME Explainer
class_names = ['Lowest Risk', 'Low Risk', 'Medium Risk', 'High Risk', 'Very High Risk', 'Default']
feature_names = important_features
jsonmodel = os.path.join(dir,"src","main","resources", "XGBoost", "X_train_important.csv")
X_train_important = pd.read_csv(jsonmodel)
lime_explainer = LimeTabularExplainer(
    X_train_important.values,
    feature_names=feature_names,
    class_names=class_names,
    mode='classification'
)

# Predict the probabilities using the correct model object
predicted_probabilities = model.predict_proba(features)
# Explain the prediction using LIME for the predicted class
exp = lime_explainer.explain_instance(
    features[0],
    model.predict_proba,
    num_features=10,
    labels=[predicted_class_encoded[0]]  # Using the actual predicted class encoded value
)
# Determine the label to use for explanation
if predicted_class_encoded[0] in exp.local_exp:
    label_to_use = predicted_class_encoded[0]
else:
    # Fall back to explaining the first available label
    label_to_use = list(exp.local_exp.keys())[0]
# Generate the figure once

fig = exp.as_pyplot_figure(label=label_to_use)
# Generate a unique filename using the current timestamp
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
lime_image_filename = f"lime_explanation_{timestamp}.png"
# Define the path to the static/images/ directory in your Spring Boot project
jsonmodel = os.path.join(dir,"src","main","resources","static","images")  # Use the parent directory and append "static"
static_dir = jsonmodel
# Ensure the directory exists (create it if it doesn't)
os.makedirs(static_dir, exist_ok=True)
# Save the LIME explanation as an image
output_path = os.path.join(static_dir, lime_image_filename)
fig.savefig(output_path, bbox_inches='tight')
plt.close(fig)
# Print the filename for the Java code to capture

# Print the predicted credit risk
print(predicted_class)
# Print the LIME image filename to be captured by the Java code
print(lime_image_filename)
